package com.elfclor;

public class Entity implements Movement{
    private String symbol;
    private String type;
    private String name;
    private int health;
    private int x;
    private int y;

    public Entity(int x, int y){
        this.x = x;
        this.y = y;
        this.symbol = ".";
        this.type = "";
        this.name = "";
        this.health = 100;
    }

    public int getHealth(){
        return this.health;  
    }

    public void setHealth(int health){
        this.health = health;
    }

    public String getType(){
        return this.type;  
    }

    public String getSymbol(){
        return this.symbol;
    }

    public String getName(){
        return this.name;
    }

    public int getX(){
        return this.x;
    }

    public int getY(){
        return this.y;
    }

    public void setType(String type){
        this.type = type;
    }

    public void setSymbol(String symbol){
        this.symbol = symbol;
    }

    public void setName(String name){
        this.name = name;
    }

    public String toString(){
        String entity = "Type: " + this.getType() + "\n" + 
                    "Name: " + this.getName() + "\n" +
                    "Health: " + this.getHealth() + "\n";

        return entity;
    }

    @Override
    public void move(int x, int y) {
        this.x = x;
        this.y = y;
        
    }
   
}
