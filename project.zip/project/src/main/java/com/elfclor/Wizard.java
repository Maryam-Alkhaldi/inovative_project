package com.elfclor;


public class Wizard extends Entity{

    private int wisdom;

    public Wizard(int x, int y,String name, int wisdom) {
        super(x, y);
        this.setName(name);
        this.setSymbol("*");
        this.setType("wizard");
        this.wisdom = wisdom;
        
    }

    public void setWisdom(int wisdom){
        this.wisdom = wisdom;
    }

    public int getWisdom(){
        return this.wisdom;
    }

    public String toString(){
        String entity = super.toString() + 
                    "Wisdom: " + this.getWisdom() + "\n";
                    

        return entity;
    }

    @Override
    public void move(int x, int y) {
        super.move(x, y);
    }
    
}
