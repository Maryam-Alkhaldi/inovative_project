package com.elfclor;

public interface Movement {
    
    public void move(int x, int y);
}
