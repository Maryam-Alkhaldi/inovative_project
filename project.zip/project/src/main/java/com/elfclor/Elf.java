package com.elfclor;

import java.util.Random;

public class Elf extends Entity{

    private boolean canFly;

    public Elf(int x, int y, String name, boolean canFly) {
        super(x, y);
        this.setName(name);
        this.canFly = canFly;
        if(this.canFly){
            this.setSymbol("&");
        } else {
            this.setSymbol("#");
        }

        this.setType("elf");
    }

    public String toString(){
        return super.toString();
    }

    public boolean isFlyingElf(){
        return this.canFly;
    }

    @Override
    public void move(int x, int y) {
        super.move(x, y);
        
    }
    
}
