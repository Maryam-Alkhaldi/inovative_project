package com.elfclor;

import java.util.Random;
import java.util.Scanner;

public class GameController {
    
    private Room gameRoom;
    private Scanner scanner;

    public GameController(){
        gameRoom = new Room();
        
        this.gameLoop();

    }

    public void gameLoop(){
        scanner = new Scanner(System.in);
        while(true){
            System.out.println("1 - Display Room");
            System.out.println("2 - Display Entity information by coordinates");
            System.out.println("3 - Reset Room");
            System.out.println("4 - Move all the entities");
            System.out.println("0 - stop");
            System.out.print("Your choice: ");

            try {
                int choice = Integer.parseInt(scanner.nextLine());
                if(choice >= 0 && choice < 5){

                    switch (choice) {
                        case 1:
                            this.displayRoom();
                            break;
                        case 2:
                            this.showInfoByCordinates();
                            break;
                        case 3:
                            this.resetRoom();
                            break;
                        case 4:
                            this.moveAllEntities();
                            break;
                        case 0:
                            System.out.println("Exiting ......");
                            return;     
                    }

                } else {
                    System.out.println("Invalid input, Please input a number between 1 to 4");
                    continue;
                }
            } catch (NumberFormatException ex) {
                System.out.println("Invalid input, Please input a number between 1 to 4");
                continue;
            }
            

            
        }
    }

    public void displayRoom(){
        System.out.println(gameRoom.toString());
    }

    public void showInfoByCordinates(){
        while(true){
            try {
                System.out.print("Enter X cordinate: ");
                int x = Integer.parseInt(scanner.nextLine());
                System.out.print("Enter Y cordinate: ");
                int y = Integer.parseInt(scanner.nextLine());

                if(x >= 0 && x < 10 && y >= 0 && y < 10){
                    Entity entity = gameRoom.getEntity(x, y);
                    if(entity.getSymbol().equals(".")){
                        System.out.println("\nNo any entity\n");
                    } else {
                        System.out.println("\nEntity properties: ");
                        System.out.println(entity.toString());
                    }
                    return;
                } else {
                    System.out.println("Invalid input, Please input a number between 0 to 9");
                    continue;
                }

            } catch (NumberFormatException ex) {
                System.out.println("Invalid input, Please input a number between 0 to 9");
                continue;
            }
            
        }
        
    }

    public void resetRoom(){
        gameRoom.resetRoom();
    }

    public void moveAllEntities(){
        gameRoom.moveEntites();
    }

    

    public static void main(String[] args) {
        // Random random = new Random();
        // int i =0;
        // while(i< 10000){
        //     System.out.println(random.nextInt(10));
        //     i++;
        // }
        
        new GameController();

    }
}
