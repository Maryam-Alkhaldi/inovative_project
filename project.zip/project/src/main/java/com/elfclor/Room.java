package com.elfclor;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Room {
    
    private List<Entity> entityList;
    private List<Entity> livingEntityList;
    private Random random;
    public Room(){
        this.entityList = new ArrayList<>();
        this.livingEntityList = new ArrayList<>();
        random = new Random();
        this.resetRoom();
    }

    public void resetRoom(){
        for(int i=0; i<10; i++){
            for(int j=0; j<10; j++){
                this.entityList.add(new Entity(i, j));
            }
        }

        // int count = 0;
        // while(count < 10){
        //     int xPos = this.getRandomX();
        //     int yPos = this.getRandomY();
        //     if(isFree(xPos, yPos)){
        //         Entity newEntity = new Entity(xPos, yPos);
        //         newEntity.setSymbol("E");
        //         newEntity.setType("Entity");
        //         addNewEntity(newEntity, xPos, yPos);
        //         count++;
        //     }
           
            
        // }

        this.livingEntityList.add(addWizard("Gandalf"));
        this.livingEntityList.add(addWizard("Saruman"));
        this.livingEntityList.add(addHobbit("Frodo", 50));
        this.livingEntityList.add(addHobbit("Bilbo", 38));
        this.livingEntityList.add(addHobbit("Sam", 128));
        this.livingEntityList.add(addElf("Galadriel", true));
        this.livingEntityList.add(addElf("Legolas", false));
        this.livingEntityList.add(addElf("Elrond", false));

    }

    public void moveEntites(){
        for(Entity entity : this.livingEntityList){
            if(entity.getType().equals("hobbit")){
                moveHobbit(entity);
            }

            if(entity.getType().equals("wizard")){
                moveWizard(entity);
            }

            if(entity.getType().equals("elf")){
                moveElf(entity);
            }
        }
    }

    private Entity addWizard(String name){
        int xPos = this.getRandomX();
        int yPos = this.getRandomY();
        while(true){
            if(isFree(xPos, yPos)){
                int wisdom = this.random.nextInt(10);
                Entity wizard = new Wizard(xPos, yPos, name, wisdom);
                addNewEntity(wizard, xPos, yPos);
                return wizard;
            } else {
                xPos = this.getRandomX();
                yPos = this.getRandomY();
            }
        }
    }

    private Entity addHobbit(String name, int age){
        int xPos = this.getRandomX();
        int yPos = this.getRandomY();
        while(true){
            if(isFree(xPos, yPos)){
                Entity hobbit = new Hobbit(xPos, yPos, name, age);
                addNewEntity(hobbit, xPos, yPos);
                return hobbit;
            } else {
                xPos = this.getRandomX();
                yPos = this.getRandomY();
            }
        }
    }

    private Entity addElf(String name, boolean canFly){
        int xPos = this.getRandomX();
        int yPos = this.getRandomY();
        while(true){
            if(isFree(xPos, yPos)){
                Entity elf = new Elf(xPos, yPos, name, canFly);
                addNewEntity(elf, xPos, yPos);
                return elf;
            } else {
                xPos = this.getRandomX();
                yPos = this.getRandomY();
            }
        }
    }

    private void moveHobbit(Entity hobbit){
        int newX = hobbit.getX() + 1;
        int newY = hobbit.getY();

        if(newX > 9){
            newX = 9;
        }

        if(!isFree(newX, newY)){
            newX = hobbit.getX();
            newY = hobbit.getY();
            while(true){
                if(newX <= 9 && newX >=0 && newY <= 9 && newY >=0 && isFree(newX, newY)){
                    break;
                }
                newX = newX + this.random.nextInt(3) + -1;
                newY = newY + this.random.nextInt(3) + -1;
            }
        }
        if(hobbit.getHealth() - 1 >= 0){
            this.addNewEntity(new Entity(hobbit.getX(), hobbit.getY()), hobbit.getX(), hobbit.getY());
            hobbit.move(newX, newY);
            hobbit.setHealth(hobbit.getHealth() - 1);
            this.addNewEntity(hobbit, newX, newY);
        }

        
    }

    private void moveWizard(Entity wizard){
        int wsidom = ((Wizard)wizard).getWisdom();
        int newX = wizard.getX();
        
        int newY = wizard.getY() - wsidom;
        if(newY < 0){
            newY = 0;
        }
        if(!isFree(newX, newY)){
            newX = wizard.getX();
            newY = wizard.getY();
            while(true){
                if(newX <= 9 && newX >=0 && newY <= 9 && newY >=0 && isFree(newX, newY)){
                    break;
                }
                newX = newX + this.random.nextInt(3) + -1;
                newY = newY + this.random.nextInt(3) + -1;
            }
        }
        if(wizard.getHealth() - wsidom >= 0){
            this.addNewEntity(new Entity(wizard.getX(), wizard.getY()), wizard.getX(), wizard.getY());
            wizard.move(newX, newY);
            wizard.setHealth(wizard.getHealth() - wsidom);
            this.addNewEntity(wizard, newX, newY);
        }

    }

    private void moveElf(Entity elf){
        boolean isFlyingElf = ((Elf) elf).isFlyingElf();

        if(isFlyingElf){
            int newX = this.getRandomX();
            int newY = this.getRandomY();

            while(!isFree(newX, newY)){
                newX = this.getRandomX();
                newY = this.getRandomY();
            }
            this.addNewEntity(new Entity(elf.getX(), elf.getY()), elf.getX(), elf.getY());
            elf.move(newX, newY);
            this.addNewEntity(elf, newX, newY);
            
        } else {

            int newX = elf.getX();
            int newY = elf.getY(); 

            while(true){
                if(newX <= 9 && newX >=0 && newY <= 9 && newY >=0 && isFree(newX, newY)){
                    break;
                }
                newX = newX + this.random.nextInt(3) + -1;
                newY = newY + this.random.nextInt(3) + -1;
            }
            int reduceHealth = this.random.nextInt(10);
            if(elf.getHealth()-reduceHealth >= 0){
                this.addNewEntity(new Entity(elf.getX(), elf.getY()), elf.getX(), elf.getY());
                elf.move(newX, newY);
                elf.setHealth(elf.getHealth()-reduceHealth);
                this.addNewEntity(elf, newX, newY);
            }
        }

        
        
    }

    public void addNewEntity(Entity e, int x, int y){
        int position = getPosition(x, y);
        this.entityList.set(position, e);
    }

    public void clearRoom(){

    }

    public boolean isFree(int x, int y){
        if(getEntity(x, y).getType().equals("")){
            return true;
        }
        return false;
    }

    private int getPosition(int x, int y){
        return y*10 + x;
    }

    private int getRandomX(){
        return this.random.nextInt(10);
    } 

    private int getRandomY(){
        return this.random.nextInt(10);
    } 

    public Entity getEntity(int x, int y){
        
        int pos = getPosition(x, y);
        return this.entityList.get(pos);
    }

    public String toString(){
        String room = "  ";
        for(int i=0; i<10; i++){
            room = room + i + "  ";
        }
        room = room + "\n";
        for(int i=0; i<10; i++){
            room = room + i + "  ";
            for(int j=0; j<10; j++){
                room = room + getEntity(j, i).getSymbol() + "  ";
            }
            room = room + "\n";
        }
        
        return room;
    }

}
