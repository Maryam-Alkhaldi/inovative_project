package com.elfclor;

public class Hobbit extends Entity{

    private int age;

    public Hobbit(int x, int y, String name, int age) {
        super(x, y);
        this.setSymbol("@");
        this.setName(name);
        this.setType("hobbit");
        this.age = age;
    }

    public void setAge(int age){
        this.age = age;
    }

    public int getAge(){
        return this.age;
    }

    public String toString(){
        String entity = super.toString() + 
                    "Age: " + this.getAge() + "\n";
                    

        return entity;
    }

    @Override
    public void move(int x, int y) {
        super.move(x, y);
    }
    
}
